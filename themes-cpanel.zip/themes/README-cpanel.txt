ستوديو القوالب — حزمة نشر cPanel
================================

خطوات النشر (داخل public_html):
1) ارفع ملف themes-cpanel.zip إلى public_html عبر File Manager ثم استخرجه،
   بحيث تصبح المسارات: public_html/themes/index.html و public_html/themes/api.php ...
2) تأكد أن مجلد server/data غير موجود (سيُنشأ تلقائياً عند أول تشغيل)
   وأن PHP في استضافتك 8.1 أو أحدث مع تفعيل pdo_sqlite (افتراضي غالباً).
3) افتح: https://yourdomain.com/themes/api/health
   يجب أن يظهر {"ok":true,...}
4) افتح التطبيق: https://yourdomain.com/themes/
   دخول المدير: admin / admin123  (غيّرها فوراً من لوحة الإدارة!)

ملاحظات:
- إذا كان الموقع في جذر public_html مباشرة (بدون مجلد themes) ستعمل
  الحزمة أيضاً دون تعديل — الروابط نسبية وتتكيف مع أي مجلد.
- ملف .htaccess يقوم بـ: حظر الوصول لمجلد server/، توجيه /api إلى api.php،
  وإرجاع أي مسار غير موجود إلى index.html (تطبيق SPA).
- إذا ظهرت أخطاء 500: فعّل عرض الأخطاء مؤقتاً أو راجع error_log في cPanel،
  وتأكد أن AllowOverride All مفعّل (افتراضي في معظم الاستضافات).
- قاعدة البيانات SQLite تُنشأ تلقائياً في server/data/app.sqlite مع
  ملف .htaccess داخلي يمنع الوصول إليها عبر الويب.
