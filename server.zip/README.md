# حزمة الخادم — ستوديو القوالب (PHP + SQLite + الواجهة المبنية)

## التشغيل (سطر واحد)
```bash
./start.sh            # أو: php -S 0.0.0.0:8080 server/router.php
```
ثم افتح: http://localhost:8080

## المتطلبات
- PHP 8.1 أو أحدث مع pdo_sqlite (مضمّنة افتراضياً)
- لا شيء غير ذلك!

## ماذا يحدث عند أول تشغيل؟
- تُنشأ قاعدة SQLite تلقائياً في server/data/app.sqlite
- يُبذر المدير (admin / admin123) وعضو تجريبي (demo / demo123)
- تُبذر الثيمات الثلاثون الجاهزة من server/seed/themes.seed.json

## المحتوى
- server/  → كود PHP (api.php المسارات، db.php القاعدة، router.php المدخل)
- dist/    → واجهة React المبنية (تُقدَّم من نفس الخادم)
- start.sh → سكربت التشغيل

## النشر على استضافة حقيقية (Apache/nginx)
- وجّه document root إلى dist/
- مرّر كل طلبات /api/* إلى server/api.php (أو استخدم router.php مع PHP المدمج)
- تأكد أن مجلد server/data قابل للكتابة

ملاحظة: bridge-run.php مخصص لبيئة المعاينة الرملية (PHP-WASM) ولا يُستخدم في التشغيل العادي.
