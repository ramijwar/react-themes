#!/usr/bin/env bash
# تشغيل سريع: خادم PHP مدمج يقدّم الواجهة (dist/) + الـ API على منفذ واحد
# المتطلبات: PHP 8.1+ مع pdo_sqlite (مفعّل افتراضياً)
cd "$(dirname "$0")"
mkdir -p server/data
echo "✔ ستوديو القوالب يعمل على http://localhost:8080"
echo "  دخول المدير: admin / admin123"
php -S 0.0.0.0:8080 server/router.php
